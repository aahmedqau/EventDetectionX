# Algorithm 2: Event Detection using BERT
from transformers import BertTokenizer, BertForSequenceClassification
import torch

def event_detection(topk_tweets, model_path="bert-base-uncased"):
    tokenizer = BertTokenizer.from_pretrained(model_path)
    model = BertForSequenceClassification.from_pretrained(model_path, num_labels=2)

    inputs = tokenizer(topk_tweets, padding=True, truncation=True, return_tensors="pt")
    outputs = model(**inputs)
    predictions = torch.argmax(outputs.logits, dim=1)

    labels = ["non-event", "event"]
    results = [labels[p.item()] for p in predictions]
    return results
