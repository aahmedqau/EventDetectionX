# Algorithm 1: Top-K Tweet Selection
def rankrag_topk_selection(tweets, instructions, k=2000):
    # Step 1: Fine-tune RankRAG with instruction tuning
    model = RankRAG.from_pretrained("meta-llama/Llama-3")
    model = instruction_tune(model, dataset=instructions)

    # Step 2: Enrich tweet context (hashtags, keywords, metadata)
    enriched_tweets = enrich_context(tweets)

    # Step 3: Retrieve relevant tweets via semantic search & entity detection
    candidates = semantic_retrieval(enriched_tweets, query_terms=['protest','earthquake','election'])

    # Step 4: Compute context richness score
    for t in candidates:
        t.score = semantic_similarity(t, query_terms) + sentiment_weight(t)

    # Step 5: Re-rank tweets and select Top-K
    topk_tweets = sorted(candidates, key=lambda x: x.score, reverse=True)[:k]
    return topk_tweets
